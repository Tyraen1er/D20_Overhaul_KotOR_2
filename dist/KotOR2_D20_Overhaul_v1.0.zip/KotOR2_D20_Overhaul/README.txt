================================================================================
  STAR WARS: KNIGHTS OF THE OLD REPUBLIC II - THE SITH LORDS
  D20 OVERHAUL MOD - Version 1.0 (English / Français)
================================================================================

[ENGLISH]
---------

ARCHIVE CONTENTS:
  - INSTALL.exe                               : TSLPatcher installer (language selector)
  - tslpatchdata/                             : Mod data folder (keep next to INSTALL.exe)
  - KotOR2_D20_Overhaul_Player_Guide_EN.pdf   : Complete Player Guide (EN)
  - KotOR2_D20_Overhaul_Guide_Joueur_FR.pdf   : Guide complet du joueur (FR)
  - HOW_TO_TRANSLATE.md                       : Guide for modders to add a new language
  - Readme.rtf                                : Mod overview

REQUIREMENTS & RECOMMENDED INSTALL ORDER:
  1. Star Wars: KotOR II (Steam, GOG, or Disc — standalone TSLRCM recommended
     over Steam Workshop for TSLPatcher compatibility).
  2. TSLRCM (The Sith Lords Restored Content Mod 1.8.6 / 2022) — strongly recommended.
  3. K2CP (KotOR 2 Community Patch v1.6.3) — optional, install BEFORE this mod.
  4. D20 Overhaul (this mod) — install AFTER TSLRCM and K2CP.

INSTALLATION:
  1. Extract the ENTIRE archive to a temporary folder (keep INSTALL.exe and
     tslpatchdata/ together).
  2. Run INSTALL.exe (as Administrator if the game is under Program Files).
  3. Choose your language in the dropdown menu (English is selected by default;
     Français is also available) and click 'Install Mod'.
  4. Select your KotOR 2 ROOT directory (the folder containing swkotor2.exe,
     NOT the Override subfolder).
  5. Wait for completion. Starting a new game is strongly recommended.

UPDATING:
  Simply run the updated INSTALL.exe pointing to your KotOR 2 folder; existing
  mod files are backed up and cleanly replaced.

UNINSTALLATION:
  TSLPatcher automatically creates a backup/ folder next to INSTALL.exe.
  Restore dialog.tlk and Override files from backup/ to revert.

WANT TO TRANSLATE THIS MOD INTO YOUR LANGUAGE?
  See HOW_TO_TRANSLATE.md included in this archive!

================================================================================

[FRANÇAIS]
----------

CONTENU DE L'ARCHIVE :
  - INSTALL.exe                               : Installateur TSLPatcher (choix de langue)
  - tslpatchdata/                             : Données du mod (NE PAS déplacer)
  - KotOR2_D20_Overhaul_Guide_Joueur_FR.pdf   : Guide complet du joueur (FR)
  - KotOR2_D20_Overhaul_Player_Guide_EN.pdf   : Complete Player Guide (EN)
  - HOW_TO_TRANSLATE.md                       : Tutoriel pour ajouter une nouvelle langue
  - Readme.rtf                                : Résumé rapide du mod

PRÉREQUIS & ORDRE D'INSTALLATION RECOMMANDÉ :
  1. Star Wars: KotOR II (Steam, GOG ou CD) — version autonome recommandée
     (évitez TSLRCM via le Steam Workshop pour les mods TSLPatcher).
  2. TSLRCM (The Sith Lords Restored Content Mod 1.8.6 / 2022) — fortement recommandé.
  3. K2CP (KotOR 2 Community Patch v1.6.3) — optionnel, à installer AVANT ce mod.
  4. D20 Overhaul (ce mod) — à installer EN DERNIER parmi les mods de gameplay.

INSTALLATION :
  1. Extrayez TOUT le contenu de ce .zip dans un dossier temporaire
     (gardez bien INSTALL.exe et le dossier tslpatchdata/ côte à côte).
  2. Lancez INSTALL.exe (en administrateur si le jeu est dans Program Files).
  3. Sélectionnez votre langue dans le menu déroulant (English par défaut,
     ou Français) puis cliquez sur « Install Mod ».
  4. Sélectionnez le dossier RACINE du jeu (celui qui contient swkotor2.exe,
     ATTENTION : NE sélectionnez PAS le sous-dossier Override !).
  5. Attendez le message de confirmation. Une nouvelle partie est fortement recommandée.

MISE À JOUR :
  Relancez simplement le nouvel INSTALL.exe sur votre dossier de jeu : les fichiers
  du mod seront automatiquement sauvegardés puis remplacés par la nouvelle version.

DÉSINSTALLATION :
  TSLPatcher crée automatiquement un dossier backup/ à côté de INSTALL.exe avant
  toute modification. Restaurez dialog.tlk et Override depuis backup/ pour revenir en arrière.
================================================================================
